﻿using System;
using System.Net.Sockets;
using System.Text;
using System.Collections.Generic; 

public class SocketFetcherNoIO
{
    public static void Main(string[] args)
    {
        Console.OutputEncoding = Encoding.UTF8;
        FetchPageViaSocket();
    }

    public static void FetchPageViaSocket()
    {
       
        Console.Write("Введіть адресу сайту (наприклад, example.com або http://example.com/): ");
        string uInput = Console.ReadLine();

        string host;
        string path = "/";
        int port = 80;

        try
        {
            if (!uInput.StartsWith("http://") && !uInput.StartsWith("https://"))
            {
                uInput = "http://" + uInput;
            }

            Uri uri = new Uri(uInput);
            host = uri.Host;
            path = uri.AbsolutePath;

            if (string.IsNullOrEmpty(path))
            {
                path = "/";
            }
        }
        catch (UriFormatException)
        {
            Console.WriteLine("Помилка: Некоректний формат URL-адреси.");
            return;
        }

        Console.WriteLine($"\n Підключення до хоста: {host} (порт {port})");
        Console.WriteLine($" Запит шляху: {path}");

        try
        {
            using (var client = new TcpClient())
            {
                client.Connect(host, port);
                NetworkStream stream = client.GetStream();

                
                string request = $"GET {path} HTTP/1.1\r\nHost: {host}\r\nConnection: close\r\n\r\n";
                byte[] requestBytes = Encoding.ASCII.GetBytes(request);
                stream.Write(requestBytes, 0, requestBytes.Length);

                
                List<byte> fullDataBytesList = new List<byte>();

                Console.WriteLine("\n" + new string('=', 50));
                Console.WriteLine("ОТРИМАННЯ ДАНИХ...");
                Console.WriteLine(new string('=', 50));

                byte[] buffer = new byte[4096];
                int bytesRead;

               
                while ((bytesRead = stream.Read(buffer, 0, buffer.Length)) > 0)
                {
                    
                    for (int i = 0; i < bytesRead; i++)
                    {
                        fullDataBytesList.Add(buffer[i]);
                    }
                }

                
                byte[] fullDataBytes = fullDataBytesList.ToArray();

                
                string decodedData = Encoding.UTF8.GetString(fullDataBytes);

                
                int headerEnd = decodedData.IndexOf("\r\n\r\n");

                if (headerEnd != -1)
                {
                    string headers = decodedData.Substring(0, headerEnd);
                    string body = decodedData.Substring(headerEnd + 4);

                    Console.WriteLine(" HTTP Заголовки:");
                    Console.WriteLine(new string('-', 50));
                    Console.WriteLine(headers);

                    Console.WriteLine("\n Тіло сторінки (сирий HTML):");
                    Console.WriteLine(new string('-', 50));
                    
                    Console.WriteLine(body);
                }
                else
                {
                    Console.WriteLine(" Отримано дані без очевидного роздільника заголовків.");
                    Console.WriteLine(new string('-', 50));
                    Console.WriteLine(decodedData);
                }
            }
        }
        catch (SocketException se)
        {
            if (se.ErrorCode == 11001)
                Console.WriteLine($"Помилка: Не вдалося визначити адресу хоста '{host}'. Перевірте правильність URL.");
            else if (se.ErrorCode == 10061)
                Console.WriteLine($"Помилка: Підключення відхилено хостом '{host}:{port}'. Хост не відповідає.");
            else
                Console.WriteLine($"Виникла помилка сокета: {se.Message}");
        }
        catch (Exception e)
        {
            Console.WriteLine($"Виникла непередбачена помилка: {e.Message}");
        }
    }
}